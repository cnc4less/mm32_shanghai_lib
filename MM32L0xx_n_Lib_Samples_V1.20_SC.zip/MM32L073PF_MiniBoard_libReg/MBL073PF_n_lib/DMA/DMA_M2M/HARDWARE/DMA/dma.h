#ifndef __DMA_H
#define __DMA_H	 
#include "HAL_conf.h"

void DMA_m8tom8_test(void);
void DMA_m8tom16_test(void);
void DMA_m8tom32_test(void);
void DMA_m16tom8_test(void);
void DMA_m16tom16_test(void);
void DMA_m16tom32_test(void);

		 				    
#endif
