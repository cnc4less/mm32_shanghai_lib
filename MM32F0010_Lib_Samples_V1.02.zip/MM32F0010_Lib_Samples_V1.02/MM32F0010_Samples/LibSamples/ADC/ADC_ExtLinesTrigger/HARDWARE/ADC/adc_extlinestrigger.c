////////////////////////////////////////////////////////////////////////////////
/// @file     adc_extlinestrigger.c
/// @author   AE TEAM
/// @brief    Use EXTI_Line11 (PB11) as the external trigger source for AD sampling
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
// Define to prevent recursive inclusion
#define _ADC_ExtllinesTrigger_C_

// Files includes
#include "adc_extllinestrigger.h"


////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Hardware_Abstract_Layer
/// @{
void ADC_RCC_ClockSet(ADC_TypeDef* ADCx, FunctionalState NewState)
{
    if(ADCx == ADC1) {
        RCC_APB1PeriphClockCmd(RCC_APB1ENR_ADC1, ENABLE);                    //Enable ADC clock
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  ADC Pin Config
/// @param  None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCxAssignPin(GPIO_TypeDef* GPIOx, u16 pin)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_StructInit(&GPIO_InitStructure);
    if(GPIOx == GPIOA) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOA, ENABLE);
    }
    else if(GPIOx == GPIOB) {
        RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB, ENABLE);
    }
    GPIO_InitStructure.GPIO_Pin  =  pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;                           //Output speed
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;                               //GPIO mode
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}
////////////////////////////////////////////////////////////////////////////////
/// @addtogroup ADC_Exported_Functions
/// @{
////////////////////////////////////////////////////////////////////////////////
/// @brief  Enable the selected ADC channel
/// @param  ADCn: where n can be 1, 2 to select the ADC peripheral.
/// @param  channel: the ADC channel to configure.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1ChannelConfig(ADCCHANNEL_TypeDef adc_channel)
{
    ADC_TypeDef* ADCn;
    ADCn = ADC1;

    ADC_ANY_Cmd(ADCn, DISABLE);                                                 //Enable and use ANYChan to control ADC sample
    ADC_ANY_NUM_Config(ADCn, 0);                                                //set Single(one) Channel as Analog iuput
    ADC_ANY_CH_Config(ADCn, 0, adc_channel);                                  //assign ADC channel 1 to RANK 0;
    ADC_ANY_Cmd(ADCn, ENABLE);                                                  //Enable and use ANYChan to control ADC sample

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Set ADCn sample time.
/// @param  ADCn: where n can be 1, 2 to select the ADC peripheral.
/// @param  channel: the ADC channel to configure.
/// @param  sampleTime: the ADC Channel n Sample time to configure.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void ADCxSampleTimeConfig(ADC_TypeDef* ADCn, ADCSAM_TypeDef sampleTime)
{
    ADCn->CFGR &= ~ADC_CFGR_SAMCTL;
    ADCn->CFGR |= sampleTime;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configure ADC1 single conversion mode��external interrupt source
///         interrupt priority
/// @note   Configure parameters according to requirements.
/// @param  ADC_Channel_x: The sampling channel
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCConfig(ADCCHANNEL_TypeDef adc_channel)
{
    ADC_InitTypeDef  ADC_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    ADC_StructInit(&ADC_InitStructure);

    //Enable ADC clock
    ADC_RCC_ClockSet(ADC1, ENABLE);                                             //Enable ADC clock
    ADCxAssignPin(GPIOA, GPIO_Pin_2);                                           //Set PA2 as  ADC channel 5
    ADC1ChannelConfig(adc_channel);

    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    //ADC prescale factor
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;
    //Set ADC mode to continuous conversion mode
    ADC_InitStructure.ADC_Mode = ADC_Mode_Imm;//ADC_Mode_Continue;
    //AD data right-justified
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_EXTI_11;
    ADC_Init(ADC1, &ADC_InitStructure);

    ADCxSampleTimeConfig(ADC1, ADC_Samctl_13_5);

    //Enable an external interrupt source
    ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);
    ADC_ExternalTrigInjectedConvConfig(ADC1, ADC1_ExternalTrigConv_EXTI_11);
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    // Configure interrupt priority
    NVIC_InitStructure.NVIC_IRQChannel = ADC1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0x02;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Gets the ADC1 transform data
/// @note   Note the register configuration if there is no return value.
/// @param  None.
/// @retval puiADData:Conversion results.
////////////////////////////////////////////////////////////////////////////////
u16 GetSingleChannelValue(void)
{
    u16 puiADData;
    //Register ADST bit enable, software start conversion
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    //ADC_IT_EOC
    while(ADC_GetFlagStatus(ADC1, ADC_IT_EOC) == 0);
    ADC_ClearFlag(ADC1, ADC_IT_EOC);
    puiADData = ADC_GetConversionValue(ADC1);
    return puiADData;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Gets the ADC1 transform data
/// @note   None.
/// @param  times:Sampling frequency
/// @retval temp_val / times:Obtain the average value of several ADC1 samples.
////////////////////////////////////////////////////////////////////////////////
u16 GetAdcAverage(u8 times)
{
    u32 temp_val = 0;
    u8 t;
    u8 delay;
    for(t = 0; t < times; t++) {
        temp_val += GetSingleChannelValue();
        for(delay = 0; delay < 100; delay++);
    }
    return temp_val / times;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  External trigger source configuration
/// @note   The IO is set to input mode
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void EXTIX_Init(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SYSCFG, ENABLE);
    // Set to pull-up input
    RCC_AHBPeriphClockCmd( RCC_AHBENR_GPIOA, ENABLE);
    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    //GPIOB.11
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource11);
    EXTI_StructInit(&EXTI_InitStructure);
    EXTI_InitStructure.EXTI_Line = EXTI_Line11;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Event;
    //Falling edge trigger
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Interrupt service function
/// @note   If error occurs,Simulation to see if you can enter the interrupt
///         function.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC1_IRQHandler(void)
{
    if(ADC_GetFlagStatus(ADC1, ADC_IT_EOC) != RESET) {

        gAdcValue = GetAdcAverage(5);
        gAdcFlag = 1;
    }
    ADC_ClearFlag(ADC1, ADC_IT_EOC);
}

/// @}

/// @}

/// @}

