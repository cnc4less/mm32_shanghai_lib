#ifndef __SYSTEM_MM32F103xCxE_o_H__
#define __SYSTEM_MM32F103xCxE_o_H__

extern uint32_t SystemCoreClock;
void SystemInit (void);

#endif
