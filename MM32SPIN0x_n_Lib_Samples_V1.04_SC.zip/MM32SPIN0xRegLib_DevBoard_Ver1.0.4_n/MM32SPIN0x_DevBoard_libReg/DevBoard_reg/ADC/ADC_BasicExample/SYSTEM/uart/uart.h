#ifndef __UART_H
#define __UART_H
#include "HAL_device.h"
#include  "stdio.h"

extern u32 SystemCoreClock;		   
void uart_initwBaudRate(u32 bound);
#endif


