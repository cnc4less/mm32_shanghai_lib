#ifndef __TIM1_H_
#define __TIM1_H_
#include "HAL_conf.h"
void Tim1_UPCount_test(u16 Prescaler,u16 Period);
void Tim1_UPStatusOVCheck_test(void);
#endif
