////////////////////////////////////////////////////////////////////////////////
/// @file    flash.c
/// @author  AE TEAM
/// @brief   THIS FILE PROVIDES SIM-EEPROM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

// Define to prevent recursive inclusion
#define _FLASH_C_

// Files includes
#include "flash.h"



#define BASED_FLASH_SECTOR_ADDRESS   0x08003000
////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Example_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup SIM_EEPROM
/// @{

u32 Data = 0x12345679;
volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
////////////////////////////////////////////////////////////////////////////////
/// @addtogroup SIM_EEPROM_Exported_Constants
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void deleyNop(u32 DlyTime)
{
    u32 i, j;
    for(i = 0; i < DlyTime; i++) {
        for(j = 0; j < 100; j++) {
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
        }
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is soft reset.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SoftReset(void)
{
    //__set_FAULTMASK(1);//For Cortex-M3,M4  Disable Interrupt
    NVIC_SystemReset();//Reset

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is check the write protect status.
/// @note   None.
/// @param  None.
/// @retval protectstatus.
////////////////////////////////////////////////////////////////////////////////
u32 CheckWriteProtectblank(void)
{

    u32 protectstatus = 0;
    u16 data1;
    s32 i = 0;

    for (i = 0; i < 4; i++) {
        data1 = *(u16*)(0x1ffff808 + i * 2);  //Address must be an integer multiple of 2
        if (data1 != 0xFFFF) {
            protectstatus = 1;
            break;
        }
    }
    return protectstatus;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is check the read protect status.
/// @note   None.
/// @param  None.
/// @retval protectstatus.
////////////////////////////////////////////////////////////////////////////////
u32 CheckReadProtect(void)
{

    u32 protectstatus = 0;
    if ((FLASH->OBR & 0x02) != (u32)RESET) {
        // Read Protect on 0x1FFFF800 is set
        protectstatus = 1;
    }
    return protectstatus;

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is portect Full main Flash enable.
/// @note   None.
/// @param  None.
/// @retval ret.
////////////////////////////////////////////////////////////////////////////////
//
s32 FLASH_EnableFullMainFlashReadOutProtect(void)
{

    FLASH_Status status = FLASH_COMPLETE;
    s32 ret = 0;
    FLASH_OPTB_Enable();
    status = FLASH_EraseOptionBytes();
    if (status != FLASH_COMPLETE)
        ret = 1;
    status = FLASH_ProgramOptionHalfWord(0x1ffff800, 0x7F80);
    if (status != FLASH_COMPLETE)
        ret = 1;
    return ret;
}



/// @}

/// @}

/// @}




