#ifndef __UART_H
#define __UART_H
#include "sys.h"
#include "stdio.h"
//////////////////////////////////////////////////////////////////////////////////

void uart_initwBaudRate(u32 bound);

#endif
















