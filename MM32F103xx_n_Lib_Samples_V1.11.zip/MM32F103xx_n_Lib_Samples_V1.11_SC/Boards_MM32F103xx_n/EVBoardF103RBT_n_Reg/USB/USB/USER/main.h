#ifndef __MAIN_H_
#define __MAIN_H_

#include "HAL_device.h"

#include "usbapp.h"                                                 //usb Ӧ��ͷ�ļ�
#endif
