#ifndef __ADC_H_
#define __ADC_H_
#include "HAL_device.h" 

void ADC1_SingleChannel(void);
u16 ADC1_SingleChannel_Get(void);
#endif
