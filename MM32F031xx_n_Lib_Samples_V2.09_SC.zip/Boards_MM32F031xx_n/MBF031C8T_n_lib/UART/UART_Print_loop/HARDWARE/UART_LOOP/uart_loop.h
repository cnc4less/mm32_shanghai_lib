#ifndef __UART_LOOP_H
#define __UART_LOOP_H
#include "HAL_conf.h"

void UartInit_Loop(void);
void Uart1RxTest(UART_TypeDef* UARTx);
		 				    
#endif
