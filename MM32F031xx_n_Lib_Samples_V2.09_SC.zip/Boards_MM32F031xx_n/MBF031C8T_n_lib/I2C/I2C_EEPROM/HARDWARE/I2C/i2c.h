#ifndef __I2C_H
#define __I2C_H	 
#include "sys.h"


void I2CMasterTest(void);				    

#endif
